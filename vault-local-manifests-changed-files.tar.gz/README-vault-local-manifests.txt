Changed behavior:
- Selection manifests: <vault>/.autoscribe/selections/<operation>.json
- Run manifest:        <vault>/.autoscribe/workflow/runs/current-run.json
- Plan records:        <vault>/.autoscribe/workflow/plans/<plan-slug>.json
- Writeback/new logs:  <vault>/.autoscribe/writeback|writenew/*-results.json
- reset-manifests now scans <vault>/.autoscribe by default.

Assumption:
- obsidian/control/scripts/plans/plan-store.js is the target location for the supplied plan-store.js.
