Dispatch Run vault-local manifest fix

Drop these files into the Obsidian control vault, preserving paths.

Changed behavior:
- workflowDir(app, name) now resolves to <vault>/.autoscribe/workflow/<name>
- operation manifests now write/read from <vault>/.autoscribe/selections/<operation>.json
- Dispatch Run selection-loader now lists and reads <vault>/.autoscribe/selections/*.json

This is intentionally a Dispatch Run / local JSON fix-up, not the SQLite migration.
