Fix for Define Plan still saving plans under ~/.local/share/autoscribe/obsidian/vaults/<key>/workflow/plans.

Changed file:
  obsidian/control/scripts/plans/plan-store.js

What changed:
  - Removed use of workflowDir from ../lib/vault-state.js.
  - plan-store.js now computes plan storage directly from the active vault root:
      <vault-root>/.autoscribe/workflow/plans/<plan-slug>.json
  - Plan records now include vault.storage = "vault-local".

After installing, create a new test plan from Define Plan. Expected path:
  <active-vault>/.autoscribe/workflow/plans/plan.<label>.<id>.json
